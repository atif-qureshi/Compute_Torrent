"""Standalone ComputeTorrent provider application."""
